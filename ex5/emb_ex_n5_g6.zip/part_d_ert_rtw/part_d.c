/*
 * File: part_d.c
 *
 * Code generated for Simulink model 'part_d'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Fri Dec  1 18:44:04 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "part_d.h"
#include "rtwtypes.h"

/* Named constants for Chart: '<Root>/Chart' */
#define part_d_IN_CLOSE                ((uint8_T)1U)
#define part_d_IN_OFF                  ((uint8_T)2U)
#define part_d_IN_OPEN                 ((uint8_T)3U)

/* Block states (default storage) */
DW_part_d_T part_d_DW;

/* External inputs (root inport signals with default storage) */
ExtU_part_d_T part_d_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_part_d_T part_d_Y;

/* Real-time model */
static RT_MODEL_part_d_T part_d_M_;
RT_MODEL_part_d_T *const part_d_M = &part_d_M_;

/* Model step function */
void part_d_step(void)
{
  /* Chart: '<Root>/Chart' incorporates:
   *  Inport: '<Root>/in_degree'
   *  Inport: '<Root>/in_light'
   */
  if (part_d_DW.is_active_c3_part_d == 0U) {
    part_d_DW.is_active_c3_part_d = 1U;
    part_d_DW.is_c3_part_d = part_d_IN_OFF;

    /* Outport: '<Root>/out_motor' */
    part_d_Y.out_motor = 0.0;
  } else {
    switch (part_d_DW.is_c3_part_d) {
     case part_d_IN_CLOSE:
      if (((part_d_U.in_light >= 45.0) && (part_d_U.in_light <= 55.0)) ||
          (part_d_U.in_degree > 80.0) || (part_d_U.in_degree < 10.0)) {
        part_d_DW.is_c3_part_d = part_d_IN_OFF;

        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = 0.0;
      } else if (part_d_U.in_light > 55.0) {
        part_d_DW.is_c3_part_d = part_d_IN_CLOSE;

        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = -1.0;
      } else if (part_d_U.in_light < 45.0) {
        part_d_DW.is_c3_part_d = part_d_IN_OPEN;

        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = 1.0;
      } else {
        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = -1.0;
      }
      break;

     case part_d_IN_OFF:
      if ((part_d_U.in_light < 45.0) && (part_d_U.in_degree <= 80.0) &&
          (part_d_U.in_degree >= 10.0)) {
        part_d_DW.is_c3_part_d = part_d_IN_OPEN;

        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = 1.0;
      } else if ((part_d_U.in_light > 55.0) && (part_d_U.in_degree <= 80.0) &&
                 (part_d_U.in_degree >= 10.0)) {
        part_d_DW.is_c3_part_d = part_d_IN_CLOSE;

        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = -1.0;
      } else {
        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = 0.0;
      }
      break;

     default:
      /* case IN_OPEN: */
      if (((part_d_U.in_light >= 45.0) && (part_d_U.in_light <= 55.0)) ||
          (part_d_U.in_degree > 80.0) || (part_d_U.in_degree < 10.0)) {
        part_d_DW.is_c3_part_d = part_d_IN_OFF;

        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = 0.0;
      } else if (part_d_U.in_light < 45.0) {
        part_d_DW.is_c3_part_d = part_d_IN_OPEN;

        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = 1.0;
      } else if (part_d_U.in_light > 55.0) {
        part_d_DW.is_c3_part_d = part_d_IN_CLOSE;

        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = -1.0;
      } else {
        /* Outport: '<Root>/out_motor' */
        part_d_Y.out_motor = 1.0;
      }
      break;
    }
  }

  /* End of Chart: '<Root>/Chart' */
}

/* Model initialize function */
void part_d_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void part_d_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
