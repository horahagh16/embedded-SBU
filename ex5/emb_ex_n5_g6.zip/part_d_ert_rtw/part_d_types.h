/*
 * File: part_d_types.h
 *
 * Code generated for Simulink model 'part_d'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Fri Dec  1 18:44:04 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_part_d_types_h_
#define RTW_HEADER_part_d_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_part_d_T RT_MODEL_part_d_T;

#endif                                 /* RTW_HEADER_part_d_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
