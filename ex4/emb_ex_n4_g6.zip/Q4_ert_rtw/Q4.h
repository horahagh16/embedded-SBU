/*
 * File: Q4.h
 *
 * Code generated for Simulink model 'Q4'.
 *
 * Model version                  : 5.2
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Mon Nov 13 21:04:42 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Q4_h_
#define RTW_HEADER_Q4_h_
#ifndef Q4_COMMON_INCLUDES_
#define Q4_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* Q4_COMMON_INCLUDES_ */

#include "Q4_types.h"
#include <stddef.h>
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  uint32_T sigR;                       /* '<Root>/traffic light ' */
} B_Q4_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  uint32_T count;                      /* '<Root>/traffic light ' */
  uint32_T pcount;                     /* '<Root>/pedestrian light ' */
  uint8_T is_active_c3_Q4;             /* '<Root>/traffic light ' */
  uint8_T is_c3_Q4;                    /* '<Root>/traffic light ' */
  uint8_T is_c1_Q4;                    /* '<Root>/pedestrian light ' */
} DW_Q4_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T Input;                        /* '<Root>/Input' */
} ExtU_Q4_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T sigG;                         /* '<Root>/sigG' */
  real_T sigY;                         /* '<Root>/sigY' */
  real_T pedG;                         /* '<Root>/pedG' */
  real_T pedR;                         /* '<Root>/pedR' */
} ExtY_Q4_T;

/* Real-time Model Data Structure */
struct tag_RTM_Q4_T {
  const char_T * volatile errorStatus;
};

/* Block signals (default storage) */
extern B_Q4_T Q4_B;

/* Block states (default storage) */
extern DW_Q4_T Q4_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_Q4_T Q4_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_Q4_T Q4_Y;

/* Model entry point functions */
extern void Q4_initialize(void);
extern void Q4_step(void);
extern void Q4_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Q4_T *const Q4_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Q4'
 * '<S1>'   : 'Q4/pedestrian light '
 * '<S2>'   : 'Q4/traffic light '
 */
#endif                                 /* RTW_HEADER_Q4_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
