/*
 * File: Q4.c
 *
 * Code generated for Simulink model 'Q4'.
 *
 * Model version                  : 5.2
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Mon Nov 13 21:04:42 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Q4.h"
#include "rtwtypes.h"

/* Named constants for Chart: '<Root>/pedestrian light ' */
#define Q4_IN_green                    ((uint8_T)1U)
#define Q4_IN_red                      ((uint8_T)2U)

/* Named constants for Chart: '<Root>/traffic light ' */
#define Q4_IN_pending                  ((uint8_T)2U)
#define Q4_IN_red_i                    ((uint8_T)3U)
#define Q4_IN_yellow                   ((uint8_T)4U)

/* Block signals (default storage) */
B_Q4_T Q4_B;

/* Block states (default storage) */
DW_Q4_T Q4_DW;

/* External inputs (root inport signals with default storage) */
ExtU_Q4_T Q4_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_Q4_T Q4_Y;

/* Real-time model */
static RT_MODEL_Q4_T Q4_M_;
RT_MODEL_Q4_T *const Q4_M = &Q4_M_;

/* Model step function */
void Q4_step(void)
{
  uint32_T qY;

  /* Chart: '<Root>/traffic light ' incorporates:
   *  Inport: '<Root>/Input'
   */
  if (Q4_DW.is_active_c3_Q4 == 0U) {
    Q4_DW.is_active_c3_Q4 = 1U;
    Q4_DW.count = 0U;
    Q4_DW.is_c3_Q4 = Q4_IN_red_i;
  } else {
    switch (Q4_DW.is_c3_Q4) {
     case Q4_IN_green:
      if ((Q4_U.Input == 1.0) && (Q4_DW.count < 60U)) {
        Q4_DW.is_c3_Q4 = Q4_IN_pending;
      } else if ((Q4_U.Input == 1.0) && (Q4_DW.count >= 60U)) {
        /* Outport: '<Root>/sigY' */
        Q4_Y.sigY = 1.0;

        /* Outport: '<Root>/sigG' */
        Q4_Y.sigG = 0.0;
        Q4_DW.count = 0U;
        Q4_DW.is_c3_Q4 = Q4_IN_yellow;
      } else if (Q4_DW.count < 60U) {
        qY = Q4_DW.count + /*MW:OvSatOk*/ 1U;
        if (Q4_DW.count + 1U < Q4_DW.count) {
          qY = MAX_uint32_T;
        }

        Q4_DW.count = qY;
        Q4_DW.is_c3_Q4 = Q4_IN_green;
      }
      break;

     case Q4_IN_pending:
      if (Q4_DW.count >= 60U) {
        /* Outport: '<Root>/sigY' */
        Q4_Y.sigY = 1.0;

        /* Outport: '<Root>/sigG' */
        Q4_Y.sigG = 0.0;
        Q4_DW.count = 0U;
        Q4_DW.is_c3_Q4 = Q4_IN_yellow;
      } else {
        qY = Q4_DW.count + /*MW:OvSatOk*/ 1U;
        if (Q4_DW.count + 1U < Q4_DW.count) {
          qY = MAX_uint32_T;
        }

        Q4_DW.count = qY;
        Q4_DW.is_c3_Q4 = Q4_IN_pending;
      }
      break;

     case Q4_IN_red_i:
      if (Q4_DW.count >= 60U) {
        /* Outport: '<Root>/sigG' */
        Q4_Y.sigG = 1.0;
        Q4_B.sigR = 0U;
        Q4_DW.count = 0U;
        Q4_DW.is_c3_Q4 = Q4_IN_green;
      } else {
        qY = Q4_DW.count + /*MW:OvSatOk*/ 1U;
        if (Q4_DW.count + 1U < Q4_DW.count) {
          qY = MAX_uint32_T;
        }

        Q4_DW.count = qY;
        Q4_DW.is_c3_Q4 = Q4_IN_red_i;
      }
      break;

     default:
      /* case IN_yellow: */
      if (Q4_DW.count >= 5U) {
        Q4_B.sigR = 1U;

        /* Outport: '<Root>/sigY' */
        Q4_Y.sigY = 0.0;
        Q4_DW.count = 0U;
        Q4_DW.is_c3_Q4 = Q4_IN_red_i;
      } else {
        qY = Q4_DW.count + /*MW:OvSatOk*/ 1U;
        if (Q4_DW.count + 1U < Q4_DW.count) {
          qY = MAX_uint32_T;
        }

        Q4_DW.count = qY;
        Q4_DW.is_c3_Q4 = Q4_IN_yellow;
      }
      break;
    }
  }

  /* End of Chart: '<Root>/traffic light ' */

  /* Chart: '<Root>/pedestrian light ' */
  if (Q4_DW.is_c1_Q4 == Q4_IN_green) {
    if (Q4_DW.pcount >= 55U) {
      /* Outport: '<Root>/pedR' */
      Q4_Y.pedR = 1.0;

      /* Outport: '<Root>/pedG' */
      Q4_Y.pedG = 0.0;
      Q4_DW.is_c1_Q4 = Q4_IN_red;
    } else {
      qY = Q4_DW.pcount + /*MW:OvSatOk*/ 1U;
      if (Q4_DW.pcount + 1U < Q4_DW.pcount) {
        qY = MAX_uint32_T;
      }

      Q4_DW.pcount = qY;
    }

    /* case IN_red: */
  } else if (Q4_B.sigR != 0U) {
    /* Outport: '<Root>/pedG' */
    Q4_Y.pedG = 1.0;

    /* Outport: '<Root>/pedR' */
    Q4_Y.pedR = 0.0;
    Q4_DW.pcount = 0U;
    Q4_DW.is_c1_Q4 = Q4_IN_green;
  }

  /* End of Chart: '<Root>/pedestrian light ' */
}

/* Model initialize function */
void Q4_initialize(void)
{
  /* Chart: '<Root>/pedestrian light ' */
  Q4_DW.is_c1_Q4 = Q4_IN_green;
}

/* Model terminate function */
void Q4_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
