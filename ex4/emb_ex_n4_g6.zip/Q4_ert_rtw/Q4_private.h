/*
 * File: Q4_private.h
 *
 * Code generated for Simulink model 'Q4'.
 *
 * Model version                  : 5.2
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Mon Nov 13 21:04:42 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Q4_private_h_
#define RTW_HEADER_Q4_private_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_Q4_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
