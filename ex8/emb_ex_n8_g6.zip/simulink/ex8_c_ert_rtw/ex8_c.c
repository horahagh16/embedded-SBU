/*
 * File: ex8_c.c
 *
 * Code generated for Simulink model 'ex8_c'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Sat Jan  6 14:19:21 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ex8_c.h"
#include "rtwtypes.h"

/* Named constants for Chart: '<Root>/car' */
#define ex8_c_IN_green                 ((uint8_T)1U)
#define ex8_c_IN_pending               ((uint8_T)2U)
#define ex8_c_IN_red                   ((uint8_T)3U)
#define ex8_c_IN_yellow                ((uint8_T)4U)

/* Named constants for Chart: '<Root>/pedestrian' */
#define ex8_c_IN_red_i                 ((uint8_T)2U)

/* Block states (default storage) */
DW_ex8_c_T ex8_c_DW;

/* External inputs (root inport signals with default storage) */
ExtU_ex8_c_T ex8_c_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_ex8_c_T ex8_c_Y;

/* Real-time model */
static RT_MODEL_ex8_c_T ex8_c_M_;
RT_MODEL_ex8_c_T *const ex8_c_M = &ex8_c_M_;

/* Model step function */
void ex8_c_step(void)
{
  uint32_T qY;

  /* Chart: '<Root>/car' incorporates:
   *  Inport: '<Root>/prdestrian'
   */
  if (ex8_c_DW.is_active_c3_ex8_c == 0U) {
    ex8_c_DW.is_active_c3_ex8_c = 1U;
    ex8_c_DW.count = 0UL;
    ex8_c_DW.is_c3_ex8_c = ex8_c_IN_red;
  } else {
    switch (ex8_c_DW.is_c3_ex8_c) {
     case ex8_c_IN_green:
      if ((ex8_c_U.prdestrian == 1.0) && (ex8_c_DW.count < 60UL)) {
        ex8_c_DW.is_c3_ex8_c = ex8_c_IN_pending;
      } else if ((ex8_c_U.prdestrian == 1.0) && (ex8_c_DW.count >= 60UL)) {
        /* Outport: '<Root>/sigY' */
        ex8_c_Y.sigY = 1.0;

        /* Outport: '<Root>/sigG' */
        ex8_c_Y.sigG = 0.0;
        ex8_c_DW.count = 0UL;
        ex8_c_DW.is_c3_ex8_c = ex8_c_IN_yellow;
      } else if (ex8_c_DW.count < 60UL) {
        qY = (uint32_T)((int16_T)ex8_c_DW.count + /*MW:OvSatOk*/ 1);
        if ((uint16_T)((int16_T)ex8_c_DW.count + 1) < (uint16_T)ex8_c_DW.count)
        {
          qY = MAX_uint32_T;
        }

        ex8_c_DW.count = qY;
        ex8_c_DW.is_c3_ex8_c = ex8_c_IN_green;
      }
      break;

     case ex8_c_IN_pending:
      if (ex8_c_DW.count >= 60UL) {
        /* Outport: '<Root>/sigY' */
        ex8_c_Y.sigY = 1.0;

        /* Outport: '<Root>/sigG' */
        ex8_c_Y.sigG = 0.0;
        ex8_c_DW.count = 0UL;
        ex8_c_DW.is_c3_ex8_c = ex8_c_IN_yellow;
      } else {
        qY = (uint32_T)((int16_T)ex8_c_DW.count + /*MW:OvSatOk*/ 1);
        if ((uint16_T)((int16_T)ex8_c_DW.count + 1) < (uint16_T)ex8_c_DW.count)
        {
          qY = MAX_uint32_T;
        }

        ex8_c_DW.count = qY;
        ex8_c_DW.is_c3_ex8_c = ex8_c_IN_pending;
      }
      break;

     case ex8_c_IN_red:
      if (ex8_c_DW.count >= 60UL) {
        /* Outport: '<Root>/sigG' */
        ex8_c_Y.sigG = 1.0;

        /* Outport: '<Root>/sigR' */
        ex8_c_Y.sigR = 0UL;
        ex8_c_DW.count = 0UL;
        ex8_c_DW.is_c3_ex8_c = ex8_c_IN_green;
      } else {
        qY = (uint32_T)((int16_T)ex8_c_DW.count + /*MW:OvSatOk*/ 1);
        if ((uint16_T)((int16_T)ex8_c_DW.count + 1) < (uint16_T)ex8_c_DW.count)
        {
          qY = MAX_uint32_T;
        }

        ex8_c_DW.count = qY;
        ex8_c_DW.is_c3_ex8_c = ex8_c_IN_red;
      }
      break;

     default:
      /* case IN_yellow: */
      if (ex8_c_DW.count >= 5UL) {
        /* Outport: '<Root>/sigR' */
        ex8_c_Y.sigR = 1UL;

        /* Outport: '<Root>/sigY' */
        ex8_c_Y.sigY = 0.0;
        ex8_c_DW.count = 0UL;
        ex8_c_DW.is_c3_ex8_c = ex8_c_IN_red;
      } else {
        qY = (uint32_T)((int16_T)ex8_c_DW.count + /*MW:OvSatOk*/ 1);
        if ((uint16_T)((int16_T)ex8_c_DW.count + 1) < (uint16_T)ex8_c_DW.count)
        {
          qY = MAX_uint32_T;
        }

        ex8_c_DW.count = qY;
        ex8_c_DW.is_c3_ex8_c = ex8_c_IN_yellow;
      }
      break;
    }
  }

  /* End of Chart: '<Root>/car' */

  /* Chart: '<Root>/pedestrian' incorporates:
   *  Outport: '<Root>/sigR'
   */
  if (ex8_c_DW.is_c1_ex8_c == ex8_c_IN_green) {
    if (ex8_c_DW.pcount >= 55UL) {
      /* Outport: '<Root>/pedR' */
      ex8_c_Y.pedR = 1.0;

      /* Outport: '<Root>/pedG' */
      ex8_c_Y.pedG = 0.0;
      ex8_c_DW.is_c1_ex8_c = ex8_c_IN_red_i;
    } else {
      qY = (uint32_T)((int16_T)ex8_c_DW.pcount + /*MW:OvSatOk*/ 1);
      if ((uint16_T)((int16_T)ex8_c_DW.pcount + 1) < (uint16_T)ex8_c_DW.pcount)
      {
        qY = MAX_uint32_T;
      }

      ex8_c_DW.pcount = qY;
    }

    /* case IN_red: */
  } else if (ex8_c_Y.sigR != 0UL) {
    /* Outport: '<Root>/pedG' */
    ex8_c_Y.pedG = 1.0;

    /* Outport: '<Root>/pedR' */
    ex8_c_Y.pedR = 0.0;
    ex8_c_DW.pcount = 0UL;
    ex8_c_DW.is_c1_ex8_c = ex8_c_IN_green;
  }

  /* End of Chart: '<Root>/pedestrian' */
}

/* Model initialize function */
void ex8_c_initialize(void)
{
  /* Chart: '<Root>/pedestrian' */
  ex8_c_DW.is_c1_ex8_c = ex8_c_IN_green;
}

/* Model terminate function */
void ex8_c_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
