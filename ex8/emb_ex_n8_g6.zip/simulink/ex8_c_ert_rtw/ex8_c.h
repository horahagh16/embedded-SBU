/*
 * File: ex8_c.h
 *
 * Code generated for Simulink model 'ex8_c'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Sat Jan  6 14:19:21 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ex8_c_h_
#define RTW_HEADER_ex8_c_h_
#ifndef ex8_c_COMMON_INCLUDES_
#define ex8_c_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* ex8_c_COMMON_INCLUDES_ */

#include "ex8_c_types.h"
#include <stddef.h>
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block states (default storage) for system '<Root>' */
typedef struct {
  uint32_T pcount;                     /* '<Root>/pedestrian' */
  uint32_T count;                      /* '<Root>/car' */
  uint8_T is_c1_ex8_c;                 /* '<Root>/pedestrian' */
  uint8_T is_active_c3_ex8_c;          /* '<Root>/car' */
  uint8_T is_c3_ex8_c;                 /* '<Root>/car' */
} DW_ex8_c_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T prdestrian;                   /* '<Root>/prdestrian' */
} ExtU_ex8_c_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T sigG;                         /* '<Root>/sigG' */
  real_T sigY;                         /* '<Root>/sigY' */
  real_T pedG;                         /* '<Root>/pedG' */
  real_T pedR;                         /* '<Root>/pedR' */
  uint32_T sigR;                       /* '<Root>/sigR' */
} ExtY_ex8_c_T;

/* Real-time Model Data Structure */
struct tag_RTM_ex8_c_T {
  const char_T * volatile errorStatus;
};

/* Block states (default storage) */
extern DW_ex8_c_T ex8_c_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_ex8_c_T ex8_c_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_ex8_c_T ex8_c_Y;

/* Model entry point functions */
extern void ex8_c_initialize(void);
extern void ex8_c_step(void);
extern void ex8_c_terminate(void);

/* Real-time Model object */
extern RT_MODEL_ex8_c_T *const ex8_c_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'ex8_c'
 * '<S1>'   : 'ex8_c/car'
 * '<S2>'   : 'ex8_c/pedestrian'
 */
#endif                                 /* RTW_HEADER_ex8_c_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
