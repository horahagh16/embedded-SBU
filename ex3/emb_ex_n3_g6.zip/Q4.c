
// defining buffers
int a[2];   
int b[4];
int c[4];
int d[2];
int e[2];

//initial tokens
int a_counter = 0;
int b_counter = 0;
int c_counter = 4;
int d_counter = 0;
int e_counter = 2;

while (1)
{
    P1();
    a_counter += 2;

    P2();
    b_counter += 2;
    a_counter -= 1;

    P2();
    b_counter += 2;
    a_counter -= 1;

    P3();
    b_counter -= 4;
    c_counter += 4;
    e_counter += 2;

    P4();
    d_counter += 1;
    e_counter -= 1;
    
    P4();
    d_counter += 1;
    e_counter -= 1;
}
