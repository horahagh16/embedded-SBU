#include <Arduino.h>
#include <Arduino_FreeRTOS.h>
#include <semphr.h>

SemaphoreHandle_t motor_Semaphore;

const int DEBUG_MODE = 1;

#define flexPin A1
#define LDRPin A0

#define M1A 6
#define M1B 7

int angle;
int lux;

void degree_reader(void *pvParameters);
void lux_reader(void *pvParameters);
void motor_task(void *pvParameters);

void setup()
{
  pinMode(LDRPin, INPUT);
  pinMode(flexPin, INPUT);

  Serial.begin(9600);

  while (!Serial)
  {
    // wait for serial port to connect. Needed for native USB, on LEONARDO, MICRO, YUN, and other 32u4 based boards.
  }
  pinMode(M1B, OUTPUT);
  pinMode(M1A, OUTPUT);

  motor_Semaphore = xSemaphoreCreateBinary();
  xSemaphoreGive(motor_Semaphore);

  xTaskCreate(motor_task, "motorTask", 256, NULL, 3, NULL);
  xTaskCreate(degree_reader, "degreeReader", 256, NULL, 2, NULL);
  xTaskCreate(lux_reader, "luxReader", 256, NULL, 2, NULL);
}

// the loop function runs over and over again forever
void loop()
{
}

void degree_reader(void *pvParameters) // This is an input task.
{

  for (;;)
  {
    int ADCflex = analogRead(flexPin);
    angle = map(ADCflex, 0, 1023, 0, 180);

    if (angle > 10 && angle < 80)
    {
      xSemaphoreGive(motor_Semaphore);
    }

    if (DEBUG_MODE)
    {
      Serial.println("flex: " + String(angle) + " degree");
      vTaskDelay(300 / portTICK_PERIOD_MS);
    }

    taskYIELD();
  }
}

void lux_reader(void *pvParameters) // This is an input task.
{

  for (;;)
  {
    int ldr = analogRead(LDRPin);
    lux = map(ldr, 10, 975, 10, 100);

    xSemaphoreGive(motor_Semaphore);

    if (DEBUG_MODE)
    {
      Serial.println("light: " + String(lux) + " lux");
      vTaskDelay(300 / portTICK_PERIOD_MS);
    }
    taskYIELD();
  }
}

void motor_task(void *pvParameters) // This is an output task .
{

  for (;;)
  {

    if (xSemaphoreTake(motor_Semaphore, portMAX_DELAY) == pdPASS)
    {

      if (angle > 10 && angle < 80)
      {

        if (lux < 45)
        {
          digitalWrite(6, HIGH);
          digitalWrite(7, LOW);
          Serial.println("motor: open");
          vTaskDelay(300 / portTICK_PERIOD_MS);
        }
        else if (lux >= 45 && lux <= 56)
        {
          digitalWrite(6, LOW);
          digitalWrite(7, LOW);
          Serial.println("motor: stop");
          vTaskDelay(300 / portTICK_PERIOD_MS);
        }
        else if (lux > 56)
        {
          digitalWrite(6, LOW);
          digitalWrite(7, HIGH);
          Serial.println("motor: close");
          vTaskDelay(300 / portTICK_PERIOD_MS);
        }
      }
      else
      {
        digitalWrite(M1A, LOW);
        digitalWrite(M1B, LOW);
        Serial.println("motor: stop");
        vTaskDelay(300 / portTICK_PERIOD_MS);
      }

      taskYIELD();
    }
  }
}
